var m = -10;

if (m == 10){
    console.log("The value of m is equal to 10");
}
else if (m < 0 && m%2 == 0){
    console.log("The value of m is less than 0 and even");
}
else{
    console.log("The value is something else");
}